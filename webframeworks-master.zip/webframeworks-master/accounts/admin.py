from django.contrib import admin
from .models import Appointment
from .models import Doctor
from .models import Department_symptoms
from .models import My_doctors
from .models import something
# Register your models here.
admin.site.register(Appointment)
admin.site.register(Doctor)
admin.site.register(Department_symptoms)
admin.site.register(My_doctors)
admin.site.register(something)