from django.test import TestCase
from django.db import models
# Create your tests here.
from django.conf import settings
from django.contrib.auth.models import AnonymousUser, User
#from django.contrib import admin
#from .models import Appointment
from .models import Doctor
#from my_project.urls import Doctor
import pytest
from mixer.backend.django import mixer
from django.test import RequestFactory
from django.urls import reverse, reverse_lazy

from accounts import views
from .forms import AppointmentForm
from .models import Doctor

pytestmark = pytest.mark.django_db

SPECIALITY_CHOICES = (
    ('dermetalogy','dermetalogy'),
    ('Cardiology', 'Cardiology'),
    ('ENT','ENT'),
    ('oncology','oncology'),
    ('neurology','neurology'),
    ('pediatrics','pediatrics'),
    ('gynecology','gynecology'),
)

GENDER_CHOICES = (('M','Male'),('F','Female'))
APP_CHOICES = (('first','First Visit'),('follow_up','Follow up'))

class Doctor(TestCase):
	doctor = models.CharField(max_length = 50)
	print("created Testdatabase Doctor")

class Appointment(TestCase):
	Name = models.CharField(max_length = 50)
	Gender = models.CharField(choices = GENDER_CHOICES,max_length = 128,default = 'M')
	dob = models.DateField(max_length = 8)
	age = models.IntegerField()
	
	phone = models.CharField(max_length= 12)
	Email = models.EmailField(max_length = 70,blank = True)
	Speciality = models.CharField(choices = SPECIALITY_CHOICES,max_length = 128)
	Appointment_catogory = models.CharField(choices = APP_CHOICES,max_length = 128,default = 'first')
	print("created Testdatabase Appointment")

class TestMyModel(TestCase):
    def test_mymodel(self):
        my_model = mixer.blend("accounts.Doctor")
        assert my_model.pk == 1, "Should create a Doctor instance"


class TestMyView(TestCase):
    def test_anonymous(self):
        req = RequestFactory().get(reverse("accounts:signup"))
        resp = views.SignUp.as_view()(req)
        assert resp.status_code == 200


class Test_AppointmentForm(TestCase):
	def test_appointmentform(self):
		form = AppointmentForm()
		assert False is form.is_valid()

		data = {"Name":"Vinutha"}
		form = AppointmentForm(data=data)
		assert False is form.is_valid()

class Test_Form_case2(TestCase):  #failed testcase
	def testform_null(self):
		form = AppointmentForm()
		assert False is form.is_valid()#assert form.errors
		assert "Name" in form.errors, "Name cannot be null"

		Name = mixer.blend("accounts.Appointment")
		data = {
		    "Name":Name.pk
		}
		form = AppointmentForm(data=data)
		assert True is form.is_valid()
		assert not form.errors, "should be no errors, when form is valid"

class Test_number(TestCase):     #failed testcase
	def test_for_name(self):
		form = AppointmentForm()
		assert False is form.is_valid()#assert form.errors
		assert "Name" in form.errors, "Name cannot be a number"
		data = {
			"Name":"43"
		}
		form = AppointmentForm(data=data)
		assert True is form.is_valid()
		assert not form.errors, "No errors, when form is valid"

class Testform_validate(TestCase):    #failed testcase
	def test_validate(self):
		Email = mixer.blend("accounts.Appointment")
		data = {
		     "Name":"Vinutha",
		     "Email":"vinuthamn0909@gmail.com"
		}
		form = AppointmentForm(data=data)
		assert form.is_valid()

		data["Email"]="bjqwhdukd"
		form = AppointmentForm(data=data)
		assert False is form.is_valid()
		assert "Email" in form.errors


class Test_Database(TestCase):
	def test_appointmentform(self):
		Email = mixer.blend("accounts.Appointment")
		form = AppointmentForm()
		assert False is form.is_valid()
		data = {
		     "Name":"abcd",
			 "Gender":"Female",
			 "Dob":1999-10-28,
			 "Age":20,
			 "phone":6360657899,
			 "Email":"vinuthamn0909@gmail.com",
			 "Speciality":"neurology"		     
		}
		form = AppointmentForm(data=data)
		assert False is form.is_valid()
		#assert "Email" in form.errors
		print("successfully added to database")

 
 class  