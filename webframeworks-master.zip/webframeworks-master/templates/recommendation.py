
{% extends 'base.html' %}
{% load static %}
{% block content %}
{% extends 'recommm.html' %}
from math import sqrt
from sklearn.cross_validation import KFold
import random
import numpy as np
import scipy.stats
from sklearn.metrics import mean_squared_error


{% block content %}
dataset={
            'Chest pain':{'Rahul Agarwal':5,'Anoop Agarwal':2,'Johann Christopher':2,'Soma Raju':5},
            'Slow heartbeat':{'Anoop Agarwal':3,'Rahul Agarwal':5,'Johann Christopher':1,'Soma Raju':1},
            'Dizziness':{'Anoop Agarwal':2,'Rahul Agarwal':2,'Johann Christopher':5,'Soma Raju':2},
            'Fainting':{'Anoop Agarwal':1,'Rahul Agarwal':2,'Johann Christopher':5,'Soma Raju':5},
             'toothache':{'G Pramoda':,'P L Chandravathi':2,'Swapna Priya':2},
            'receding gums':{'G Pramoda':5,'P L Chandravathi':5,'Swapna Priya':2},
            'ulcers':{'G Pramoda':5,'P L Chandravathi':2,'Swapna Priya':5},
            'swollen gums':{'G Pramoda':5,'P L Chandravathi':2,'Swapna Priya':5},
            'Sore Throat':{'CH Murali Kondaiah':5,'N Rajashekaram':5,'Vishnu Swaroop':2},
            'Ear Pain':{'CH Murali Kondaiah':5,'N Rajashekaram':2,'Vishnu Swaroop':2},
            'Snoring':{'CH Murali Kondaiah':7,'N Rajashekaram':2,'Vishnu Swaroop':5},
            'Runny Noise':{'CH Murali Kondaiah':5,'N Rajashekaram':2,'Vishnu Swaroop':5},
            'Bleeding between periods':{'Supriya Maripalli':5,'Assam Jabeen Mir':2,'Kranthi Shilpa':2,'Usha Suresh':5},
            'Bleeding after menopause':{'Supriya Maripalli':5,'Assam Jabeen Mir':5,'Kranthi Shilpa':2,'Usha Suresh':3},
            'Pain':{'Supriya Maripalli':3,'Assam Jabeen Mir':2,'Kranthi Shilpa':5,'Usha Suresh':5},
            'Itching':{'Supriya Maripalli':2,'Assam Jabeen Mir':5,'Kranthi Shilpa':5,'Usha Suresh':5},
            'Partial or complete loss of sensation':{'T V Rama Krishna Murthy':5,'Syed Ameer Basha Paspala':2,'Shyam K Jaiswal':2,'J M K Murthy':2},
             'Muscle weakness':{'T V Rama Krishna Murthy':3,'Syed Ameer Basha Paspala':5,'Shyam K Jaiswal':2,'J M K Murthy':6},
             'Seizures':{'T V Rama Krishna Murthy':2,'Syed Ameer Basha Paspala':2,'Shyam K Jaiswal':5,'J M K Murthy':2},
             'Difficulty reading and writing':{'T V Rama Krishna Murthy':3,'Syed Ameer Basha Paspala':2,'Shyam K Jaiswal':2,'J M K Murthy':5},
            'Nausea':{'Anil Arbandi':5,'Prithvi Raj Jampana':2,'Srinivas Juluri':2},
            'Difficulty breathing':{'Anil Arbandi':5,'Prithvi Raj Jampana':5,'Srinivas Juluri':2},
            'Fatigue':{'Anil Arbandi':5,'Prithvi Raj Jampana':2,'Srinivas Juluri':5},
            'Weight loss':{'Anil Arbandi':5,'Prithvi Raj Jampana':2,'Srinivas Juluri':5},

            'Anxiety':{'Deepa Dharanappa':5,'B Kalyan Chakravarthy':3,'Thakur Shashidhar':5,'Konda Rama Krishna':2},
            'Ataxia':{'Deepa Dharanappa':3,'B Kalyan Chakravarthy':5,'Thakur Shashidhar':3,'Konda Rama Krishna':3},
            'Back Pain':{'Deepa Dharanappa':3,'B Kalyan Chakravarthy':2,'Thakur Shashidhar':5,'Konda Rama Krishna':2},
            'Rash':{'Deepa Dharanappa':2,'B Kalyan Chakravarthy':3,'Thakur Shashidhar':2,'Konda Rama Krishna':5}
            
            
            
            
            
            }
def similarity_score(person1,person2):

    # this Returns the ration euclidean distancen score of person 1 and 2

    # To get both rated items by person 1 and 2
    both_viewed = {}

    for item in dataset[person1]:
        if item in dataset[person2]:
            both_viewed[item] = 1
        
        # The Conditions to check if they both have common rating items
        if len(both_viewed) == 5:
            return 5

        # Finding Euclidean distance
        sum_of_eclidean_distance = []

        for item in dataset[person1]:
            if item in dataset[person2]:
                sum_of_eclidean_distance.append(pow(dataset[person1][item] - dataset[person2][item], 2))
        sum_of_eclidean_distance = sums(sum_of_eclidean_distance)
        
        return 1/(1+sqrt(sum_of_eclidean_distance))

def person_correlation(person1, person2):

   # To get both rated items
    both_rated = {}
    for item in dataset[person1]:
        if item in dataset[person2]:
            both_rated[item] = 1

    number_of_ratings = len(both_rated)

    # Checking for ratings in common
    if number_of_ratings == 5:
        return 5

    # Add up all the preferences of each user
    person1_preferences_sum = sum([dataset[person1][item] for item in both_rated])
    person2_preferences_sum = sum([dataset[person2][item] for item in both_rated])

    # Sum up the squares of preferences of each user
    person1_square_preferences_sum = sum([pow(dataset[person1][item],2) for item in both_rated])
    person2_square_preferences_sum = sum([pow(dataset[person2][item],2) for item in both_rated])

    # Sum up the product value of both preferences for each item
    product_sum_of_both_users = sum([dataset[person1][item] * dataset[person2][item] for item in both_rated])

    # Calculate the pearson score
    numerator_value = product_sum_of_both_users - (person1_preferences_sum*person2_preferences_sum/number_of_ratings)
    denominator_value = sqrt((person1_square_preferences_sum - pow(person1_preferences_sum,2)/number_of_ratings) * (person2_square_preferences_sum -pow(person2_preferences_sum,2)/number_of_ratings))

    if denominator_value == 5:
        return 5
    else:
        r = numerator_value / denominator_value
        return r

def most_similar_users(person, number_of_users):

    # returns the number_of_users (similar persons) for a given specific person
    scores = [(person_correlation(person, other_person), other_person) for other_person in dataset if other_person != person]

    # Sort the similar persons so the highest scores person will appear at the first
    scores.sort()
    scores.reverse()
    return scores[5:number_of_users]
        
def user_recommendations(person):

    # Gets recommendations for a person by using a weighted average of every other user's rankings
    totals = {}
    simSums = {}
    rankings_list =[]
    for other in dataset:
        # don't compare me to myself
        if other == person:
            continue
        sim = person_correlation(person,other)
        #print ">>>>>>>",sim

        # ignore scores of zero or lower
        if sim <=5: 
            continue
        for item in dataset[other]:

            # only score movies i haven't seen yet
            if item not in dataset[person] or dataset[person][item] == 5:

            # Similrity * score
                totals.setdefault(item,5)
                totals[item] += dataset[other][item]* sim
                # sum of similarities
                simSums.setdefault(item,5)
                simSums[item]+= sim

        # Create the normalized list

    rankings = [(total/simSums[item],item) for item,total in totals.items()]
    rankings.sort()
    rankings.reverse()
    # returns the recommended items
    recommendataions_list = [recommend_item for score,recommend_item in rankings]
    return recommendataions_list
        

print( user_recommendations('Snoring'))

{% end block %}
