from django.shortcuts import render,redirect

# Create your views here.
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from .models import Doctors
from .forms import AppointmentForm
from django.contrib.auth import views as auth_views

class SignUp(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'signup.html'

def homepage(request):
	return render(request,"homepage.html",{})
def derm(request):
	return render(request,"derm.html",{})
def ent(request):
	return render(request,"ent.html",{})
def gyn(request):
	return render(request,"gynic.html",{})
def card(request):
	return render(request,"card.html",{})
def pedia(request):
	return render(request,"Pediatricinas.html",{})
def onc(request):
	return render(request,"onc.html",{})
def neuro(request):
	return render(request,"neuro.html",{})
def branches(request):
	return render(request,"contact.html",{})
def rights(request):
	return render(request,"rights.html",{})
def health(request):
	return render(request,"healthtips.html",{})
def app_form(request):
	return render(request,"app_form.html",{})
def multipage(request):
	return render(request,"multipage.html",{})

def search_titles(request,):
    print("inside search_titles")

    if(request.method=="POST"):
        search_text=request.POST.get('search_text')
        print(search_text)
    else:
        search_text=''
    valid=Doctors.objects.filter(doctors__contains= search_text)
    
    print("searching ", search_text)
    print("valid :",valid)
    return render(request,'Ajax_search.html',{'skills':valid})
	
def app_new(request):
	if request.method == "POST":
		form = AppointmentForm(request.POST)
		
		if form.is_valid():
			post = form.save(commit=False)
			post.save()
			return redirect('homepage')
			
	else:
		form = AppointmentForm()
	return render(request, 'post_edit.html', {'form': form})
